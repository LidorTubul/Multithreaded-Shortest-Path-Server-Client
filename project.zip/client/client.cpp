// Lidor Tubul 318944402
// Lotem Cohen 324266774
// Yonatan Ori 316002112

#include "sys/types.h"
#include <sys/socket.h>
#include "unistd.h"
#include "std_lib_facilities.h"
#include <pthread.h>
#include <sys/wait.h>
#include <unordered_set>
#include <queue>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>

int main(int argc, char **argv){

    string port = argv[2];
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    
    sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(argv[1]);
    addr.sin_port = htons(stoi(port));
    
    connect(fd, (sockaddr*)&addr, sizeof(addr));

    string m = (string)argv[3]+" "+(string)argv[4]; 
    char result[1000];

    write(fd, m.c_str(), m.size());
    int n = read(fd, result, sizeof(result));

    string r(result, n);

    cout << r << endl;
    close(fd);
    return 0;
}