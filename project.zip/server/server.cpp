// Lidor Tubul 318944402
// Lotem Cohen 324266774
// Yonatan Ori 316002112

#include "server.h"

unordered_map<string, vector<string>> graph__;
Vector<Path_> paths;
pthread_mutex_t m1 = PTHREAD_MUTEX_INITIALIZER;


// function to perform bfs and return the shortest path as a string
string breadthFirstSearch(const string& start, const string& goal) {
    queue<pair<string, string>> Queue; // Queue of (node, path) pairs
    unordered_set<string> visited;
    
    // enqueue the start node with an empty path
    Queue.push({start, start});
    visited.insert(start);

    while (!Queue.empty()) {
        auto [currentNode, currentPath] = Queue.front();
        Queue.pop();

        // check if the current node is the goal
        if (currentNode == goal) {
            return currentPath + "\n"; // return the shortest path
        }

        // enqueue unvisited children with updated paths
        for (const auto& child : graph__.at(currentNode)) {
            if (visited.find(child) == visited.end()) {
                Queue.push({child, currentPath + " -> " + child});
                visited.insert(child);
            }
        }
    }

    // if goal not reached, return an Not Exist message
    return "Not Exist\n";
}

// check the last 10 paths that server has givven answer to, if requested path exist it will send the path without further calculations, 
// else return string of "empty".
string check_vector(string start, string end)
{
    pthread_mutex_lock(&m1);
    string f = "empty";

    for (const auto& path : paths) {
        if(path.start == start && path.end == end)
        {
            f =  path.path;
        }
    }

    pthread_mutex_unlock(&m1);
    return f;
}

// reads new request from new client (which identified by fd2 varaible) and check if path is exist in paths vector,
// if it's there it will write the path to the client with no further calculations. else it will calculate the shortest path. if not exist will write "empty".  
void* BFS(void* arg)
{
    int fd2 = (int)(long)arg;

    char str[1000];
    int n = read(fd2, str, 1000); 
    
    string s(str, n);
    stringstream ss(s);
    string start;
    string end;

    // split the string and put the values of the request in start and end
    ss >> start >> end;

    string p = check_vector(start, end);

    string result;
    if(p != "empty") 
    {
        result = p;
    }
    else
    {
        result = breadthFirstSearch(start, end);

        if(paths.size() == 10) paths.erase(paths.begin());
        
        paths.push_back(Path_{start, end, result});
    }

    write(fd2, &result[0], result.size());

    close(fd2);

    return NULL;

}

// create the undirected graph from any textual file given from the server operator in form of a link between two vertexses and a space between
// them. put all vertexses in map which the keys are vertexses and values are vector of strings that represent the edges from any practicular vertex(key)
void graph_creator(string filePath)
{
    ifstream db(filePath);
    string u, v;

    while (db >> u >> v) {
        graph__[u].push_back(v);
        graph__[v].push_back(u);
    }

}

int main(int argc, char **argv)
{
    graph_creator(argv[1]);
    string port = argv[2];

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr.sin_port = htons(stoi(port));

    bind(fd, (sockaddr*) &addr, sizeof(addr));
    listen(fd, 10);
    for(;;)
    {
        int fd2 = accept(fd, NULL, NULL);
        pthread_t t1;
        pthread_create(&t1, NULL, BFS, (void*)(long)fd2);
    }
    return 0;
}