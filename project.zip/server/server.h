// Lidor Tubul 318944402
// Lotem Cohen 324266774
// Yonatan Ori 316002112

#include "sys/types.h"
#include <sys/socket.h>
#include "unistd.h"
#include "std_lib_facilities.h"
#include <pthread.h>
#include <sys/wait.h>
#include <unordered_set>
#include <queue>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>

struct Path_
{
    string start;
    string end;
    string path;
};

string check_vector(string start, string end);

void* BFS(void* arg);
void graph_creator(string filePath);

string breadthFirstSearch(const string& start, const string& goal);

